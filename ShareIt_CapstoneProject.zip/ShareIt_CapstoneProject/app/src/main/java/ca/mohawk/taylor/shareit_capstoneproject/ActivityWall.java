package ca.mohawk.taylor.shareit_capstoneproject;

import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;

/*
 *
 * Share it, Photo sharing and Messaging Application
 *
 * Christopher Taylor, 000377293
 *
 * Mohawk College
 * Software Capstone - COMP-10202-01
 *
 * I, Christopher Taylor, 000377293 certify that this material is my original work.
 * No other person's work has been used without due acknowledgement.
 *
 * */

public class ActivityWall extends AppCompatActivity {

    private RecyclerView cardView;

    //get reference to the database to set up queuries later
    private DatabaseReference PostDatabase;
    private DatabaseReference UserDatabase;

    private FirebaseAuth firebaseAuth;

    private String userID;

    //create an adapter with type WallPost and using the post view holder
    private FirebaseRecyclerAdapter<WallPost, ActivityWall.PostViewHolder> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wall);

        //get instance of app for firebase
        firebaseAuth = FirebaseAuth.getInstance();

        //set up the recycler view with the cardview layout
        cardView = (RecyclerView) findViewById(R.id.wall_list_view);
        cardView.setHasFixedSize(true);
        cardView.setLayoutManager(new LinearLayoutManager(this));

        userID = getIntent().getStringExtra("userID");

        //get all posts in the database by the user passed in
        //simultaneously handles either current user or another user
        //because the way the data is retreived
        PostDatabase = FirebaseDatabase.getInstance().getReference().child("Posts").child(userID);

        //creating a firebase options.
        //this will take a query from the database reference that gets posts
        //for the purpose of passing posts into the recyclerview
        FirebaseRecyclerOptions options = new FirebaseRecyclerOptions.Builder<WallPost>().setQuery(PostDatabase, WallPost.class).build();

        //set the adapter with options passed in
        adapter = new FirebaseRecyclerAdapter<WallPost, PostViewHolder>(options) {
            @Override
            protected void onBindViewHolder(final PostViewHolder holder, int position, @NonNull final WallPost post) {

                //pass in the data found in the posts on the database to be displayed in the holder
                try{
                    holder.setCaption(post.getDescription());
                    holder.setImage(post.media_url, getApplicationContext());
                    holder.setDate(getDate(post.timestamp));

                //TODO get video url from storage on firebase
                // holder.setVideo(post.media_url);

                } catch (Exception e) {
                }

                //get the current user's data that is being viewed
                UserDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child(userID);

                //get the users thumbnail and username to be pass into the holder
                UserDatabase.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        String image = dataSnapshot.child("thumb_photo").getValue().toString();
                        String username = dataSnapshot.child("username").getValue().toString();

                        //pass in the thumnail image found to the circle imageview using the Picasso library
                        try {
                            holder.usernameView.setText(username);
                            Picasso.with(holder.thumbView.getContext()).load(image).placeholder(R.drawable.ic_account2).into(holder.thumbView);
                        } catch (Exception e) {

                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }

            @NonNull
            @Override
            public ActivityWall.PostViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

                //create a new post with viewholder set to the custom user search layout
                final View myView = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_layout, parent, false);
                return new ActivityWall.PostViewHolder(myView);
            }
        };

        //set the adapter now that everything is finished setting up
        cardView.setAdapter(adapter);

    }

    //have the adapter start listening on start up
    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    //have is stop listening on stop to save memory
    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }

    //get the long time passed in and convert it to a datetime.
    private String getDate(long time) {
        Calendar cal = Calendar.getInstance(Locale.ENGLISH);
        cal.setTimeInMillis(time);
        String date = DateFormat.format("MMMM dd hh:mm aa", cal).toString();
        return date;
    }

    //create the user viewholder, this holds the data for each post in the recycler view
    public class PostViewHolder extends RecyclerView.ViewHolder{

        View myView;
        String userID;

        TextView usernameView;
        CircleImageView thumbView;
        TextView dateView;

        public PostViewHolder(View itemView) {
            super(itemView);
            myView = itemView;

            usernameView = (TextView) myView.findViewById(R.id.card_username);
            thumbView = (CircleImageView) myView.findViewById(R.id.card_thumb_image);

        }

        //description/caption passed in when viewholder is bound, text is updated here
        public void setCaption(String caption) {

            TextView captionView = (TextView) myView.findViewById(R.id.card_description);
            captionView.setText(caption);
        }

        //date passed in when viewholder is bound, text is updated here
        public void setDate(String timestamp) {

            TextView dateView = (TextView) myView.findViewById(R.id.card_date);
            dateView.setText(timestamp);
        }

        //image passed in when viewholder is bound, image is updated here
        public void setImage(String post_photo, Context ctx) {

            //hide the videoview since its overlapping the imageview
            //and not needed if the post is an image
            VideoView videoView = (VideoView) myView.findViewById(R.id.card_video);
            videoView.setVisibility(View.GONE);

            ImageView imageView = (ImageView) myView.findViewById(R.id.card_image);
//          imageView.setVisibility(View.GONE);

            ImageView photoView = (ImageView) myView.findViewById(R.id.card_image);
            Picasso.with(ctx).load(post_photo).fit().into(photoView);
            Picasso.with(ctx).load(post_photo).fit().centerCrop().placeholder(R.drawable.ic_error).into(photoView);

        }



        //TODO still need to get download url from storage on firebase
//        public void setVideo(String videoUri) {
//            VideoView videoView = (VideoView) myView.findViewById(R.id.card_video);
//            videoView.setVisibility(View.GONE);
//
//            Uri uri = Uri.parse("https://firebasestorage.googleapis.com/v0/b/shareit-6cac3.appspot.com/o/shared_videos%2FcmQodOTQL8OrHGzFLLXNY3MyB5l1%2F264HG%7B'BU_Cjb%7C%20BRY?alt=media&token=27935873-eca9-4f03-9da7-6674a24164ae");
//            videoView.setVideoURI(uri);
//            videoView.requestFocus();
//            videoView.start();
//
//            videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
//                @Override
//                public void onPrepared(MediaPlayer mp) {
//                    mp.setLooping(true);
//                   // mp.setVolume(0, 0);
//                }
//            });
//
////            videoView.getLayoutParams().height = 700;
////            videoView.getLayoutParams().width = 1020;
//        }

    }
}
