package ca.mohawk.taylor.shareit_capstoneproject;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

/*
 *
 * Share it, Photo sharing and Messaging Application
 *
 * Christopher Taylor, 000377293
 *
 * Mohawk College
 * Software Capstone - COMP-10202-01
 *
 * I, Christopher Taylor, 000377293 certify that this material is my original work.
 * No other person's work has been used without due acknowledgement.
 *
 * */

public class ActivityPasswordReset extends AppCompatActivity {

    private FirebaseAuth firebaseAuth;
    EditText emailinput;
    String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_reset);

        emailinput = (EditText) findViewById(R.id.txtEdit_passwordresetemail);
        firebaseAuth = FirebaseAuth.getInstance();

    }

    //Handle the password reset button clicked
    public void ForgotPassword(View view) {

        email = emailinput.getText().toString().trim();

        //make sure the edit text isn't empty for when trying to send the reset email
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(getApplicationContext(), "Enter your email!", Toast.LENGTH_SHORT).show();
            return;
        }

        //take the email passed in and have firebase handle the reset password link being sent off
        firebaseAuth.sendPasswordResetEmail(email).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {

                if (task.isSuccessful()) {
                    Toast.makeText(ActivityPasswordReset.this, "Password reset link sent to email", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(ActivityPasswordReset.this, "Failed to send password reset link", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
