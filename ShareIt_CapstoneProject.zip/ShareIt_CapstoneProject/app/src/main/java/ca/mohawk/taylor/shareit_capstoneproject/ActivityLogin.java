package ca.mohawk.taylor.shareit_capstoneproject;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

/*
 *
 * Share it, Photo sharing and Messaging Application
 *
 * Christopher Taylor, 000377293
 *
 * Mohawk College
 * Software Capstone - COMP-10202-01
 *
 * I, Christopher Taylor, 000377293 certify that this material is my original work.
 * No other person's work has been used without due acknowledgement.
 *
 * */

public class ActivityLogin extends AppCompatActivity {

    private EditText mEmail;
    private EditText mPassword;

    private ProgressDialog loginProgress;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //get current instance of app for firebase
        firebaseAuth = FirebaseAuth.getInstance();

        mEmail = (EditText) findViewById(R.id.txtEdit_EmailLogin);
        mPassword = (EditText) findViewById(R.id.txtEdit_PasswordLogin);
        loginProgress = new ProgressDialog(this);

    }

    //Handle login button pressed
    public void Login(View view) {
        startSignIn();
    }

    //Handle create account button pressed
    public void CreateAccount(View view) {
        Intent intent = new Intent(this, AccountCreation_Activity.class);
        startActivity(intent);
    }

    //handle user sign in functionality
    private void startSignIn() {

        String email = mEmail.getText().toString();
        String password = mPassword.getText().toString();

        //make sure no fields are empty
        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {

            Toast.makeText(ActivityLogin.this, "Login fields cannot be empty", Toast.LENGTH_SHORT).show();

        } else {

            //notify the user with a dialog they are being logged in
            loginProgress.setTitle("Logging in...");
            loginProgress.setMessage("Please wait...");
            loginProgress.setCanceledOnTouchOutside(false);
            loginProgress.show();

            //handle user sign in with email and password, if there is a match in the database, user should sign in properly, otherwise notified their input was wrong
            firebaseAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {

                    loginProgress.hide();

                    if (!task.isSuccessful()) {
                        Toast.makeText(ActivityLogin.this, "Incorrect email or password", Toast.LENGTH_SHORT).show();
                    } else {

                        //if login is successful go to account activity
                        Intent intent = new Intent(ActivityLogin.this, Account_Activity.class);
                        startActivity(intent);
                    }
                }
            });
        }
    }

    //if forgot password button pressed start the password reset activity
    public void ForgotPassword(View view) {

        Intent intent = new Intent(ActivityLogin.this, ActivityPasswordReset.class);
        startActivity(intent);

    }
}
