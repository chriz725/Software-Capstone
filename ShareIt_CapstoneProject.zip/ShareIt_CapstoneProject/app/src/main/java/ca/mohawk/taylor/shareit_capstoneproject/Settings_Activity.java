package ca.mohawk.taylor.shareit_capstoneproject;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.NetworkOnMainThreadException;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/*
 *
 * Share it, Photo sharing and Messaging Application
 *
 * Christopher Taylor, 000377293
 *
 * Mohawk College
 * Software Capstone - COMP-10202-01
 *
 * I, Christopher Taylor, 000377293 certify that this material is my original work.
 * No other person's work has been used without due acknowledgement.
 *
 * */

public class Settings_Activity extends AppCompatActivity {

    FirebaseUser firebaseUser;
    private DatabaseReference UserDatabase;

    ProgressBar mProgressbar;

    private EditText mUsername;
    private EditText first_name;
    private EditText last_name;
    private EditText mbirthday;
    private EditText phone;
    private EditText bio;

    String username;
    String firstname;
    String lastname;
    String birthday;
    String phonenumber;
    String biography;

    //set the date format for when user selects a date for birthday using datepicker
    String dateFormat = "MMMM dd, yyyy";
    Calendar myCalendar = Calendar.getInstance();
    DatePickerDialog.OnDateSetListener date;
    SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, Locale.CANADA);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        //create a progress bar and set it to invisible
        mProgressbar = (ProgressBar) findViewById(R.id.progressBar_settings);
        mProgressbar.setVisibility(View.INVISIBLE);

        mbirthday = (EditText) findViewById(R.id.editText_birthday_settings);
        date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, month);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateDate();

            }
        };

        //get the current user and his ID if he is logged in
        if (firebaseUser == null) {
            firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
            String current_uid = firebaseUser.getUid();
            UserDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child(current_uid);

            mUsername = (EditText) findViewById(R.id.editText_username_settings);
            first_name = (EditText) findViewById(R.id.editText_firstname_settings);
            last_name = (EditText) findViewById(R.id.editText_lastname_settings);
            mbirthday = (EditText) findViewById(R.id.editText_birthday_settings);
            phone = (EditText) findViewById(R.id.editText_phone_settings);
            bio = (EditText) findViewById(R.id.editText_bio_settings);

        //if no user is logged in, send user to login page
        } else {
            Intent intent = new Intent(this, ActivityLogin.class);
            startActivity(intent);
        }

        //get all the user data from the database and load it into the edittexts
        try {
            UserDatabase.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    if (firebaseUser != null) {

                        username = dataSnapshot.child("username").getValue().toString();
                        firstname = dataSnapshot.child("first_name").getValue().toString();
                        lastname = dataSnapshot.child("last_name").getValue().toString();
                        birthday = dataSnapshot.child("birthday").getValue().toString();
                        phonenumber = dataSnapshot.child("phone").getValue().toString();
                        biography = dataSnapshot.child("bio").getValue().toString();

                        //String image = dataSnapshot.child("image").getValue().toString();

                        mUsername.setText(username);
                        first_name.setText(firstname);
                        last_name.setText(lastname);
                        mbirthday.setText(birthday);
                        phone.setText(phonenumber);
                        bio.setText(biography);

                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    System.out.println("The read failed: " + databaseError.getCode());
                }
            });

        } catch (Exception e) {
            //Log.e("ERROR", "Failed to load in data");
        }


    }

    //when the birthday edit text is clicked show the date picker
    public void showCalendar(View view) {

        new DatePickerDialog(Settings_Activity.this, R.style.datepicker, date, myCalendar
                .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void updateDate() {
        mbirthday.setText(sdf.format(myCalendar.getTime()));
    }

    //handle when the save button is pressed.
    public void updateSettings(View view) {

        //progress bar is visible to show user there is something processing
        mProgressbar.setVisibility(View.VISIBLE);

        String username = mUsername.getText().toString();
        String firstname = first_name.getText().toString();
        String lastname = last_name.getText().toString();
        String birthday = mbirthday.getText().toString();
        String phonenumber = phone.getText().toString();
        String biography = bio.getText().toString();

        //update the database with the same data that is store in the edittexts
        UserDatabase.child("username").setValue(username).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    mProgressbar.setVisibility(View.INVISIBLE);
                } else {
                    Toast.makeText(Settings_Activity.this, "Error saving settings", Toast.LENGTH_LONG).show();
                }
            }
        });

        UserDatabase.child("first_name").setValue(firstname).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    mProgressbar.setVisibility(View.INVISIBLE);
                } else {
                    Toast.makeText(Settings_Activity.this, "Error saving settings", Toast.LENGTH_LONG).show();
                }
            }
        });
        UserDatabase.child("last_name").setValue(lastname).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    mProgressbar.setVisibility(View.INVISIBLE);
                } else {
                    Toast.makeText(Settings_Activity.this, "Error saving settings", Toast.LENGTH_LONG).show();
                }
            }
        });
        UserDatabase.child("birthday").setValue(birthday).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    mProgressbar.setVisibility(View.INVISIBLE);
                } else {
                    Toast.makeText(Settings_Activity.this, "Error saving settings", Toast.LENGTH_LONG).show();
                }
            }
        });
        UserDatabase.child("phone").setValue(phonenumber).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    mProgressbar.setVisibility(View.INVISIBLE);
                } else {
                    Toast.makeText(Settings_Activity.this, "Error saving settings", Toast.LENGTH_LONG).show();
                }
            }
        });
        UserDatabase.child("bio").setValue(biography).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    mProgressbar.setVisibility(View.INVISIBLE);
                } else {
                    Toast.makeText(Settings_Activity.this, "Error saving settings", Toast.LENGTH_LONG).show();
                }
            }
        });

        Toast.makeText(this, "Settings Saved", Toast.LENGTH_SHORT).show();


    }
}
