package ca.mohawk.taylor.shareit_capstoneproject;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import de.hdodenhof.circleimageview.CircleImageView;

/*
 *
 * Share it, Photo sharing and Messaging Application
 *
 * Christopher Taylor, 000377293
 *
 * Mohawk College
 * Software Capstone - COMP-10202-01
 *
 * I, Christopher Taylor, 000377293 certify that this material is my original work.
 * No other person's work has been used without due acknowledgement.
 *
 * */

public class ConversationsActivity extends AppCompatActivity {

    private RecyclerView conversationList;

    //get reference to the database to set up queuries later
    private DatabaseReference ConversationDatabase;
    private DatabaseReference MessageDatabase;
    private DatabaseReference UsersDatabase;

    private FirebaseAuth firebaseAuth;

    private String current_user;

    //create an adapter with type conversations and using the conversations view holder
    private FirebaseRecyclerAdapter<Conversations, ConversationsActivity.ConversationsViewHolder> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conversations);

        conversationList = (RecyclerView) findViewById(R.id.conversation_list);

        //get instance of the app through firebase
        firebaseAuth = FirebaseAuth.getInstance();

        //get the current user loggin in
        current_user = firebaseAuth.getCurrentUser().getUid();

        //get the children of the current user in chats for reference
        ConversationDatabase = FirebaseDatabase.getInstance().getReference().child("Chat").child(current_user);

        //get all the users in the database for reference
        UsersDatabase = FirebaseDatabase.getInstance().getReference().child("Users");
        //get all the friends in the datavase for reference
        MessageDatabase = FirebaseDatabase.getInstance().getReference().child("Messages").child(current_user);

        //manage layout of active conversations
        //display them backwards from oldest to newest
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);

        conversationList.setHasFixedSize(true);
        conversationList.setLayoutManager(linearLayoutManager);

        //order the conversations by time they were last posted
        Query conversationQuery = ConversationDatabase.orderByChild("timestamp");

        //creating a firebase options.
        //this will take a query from the database reference that gets conversations
        //for the purpose of passing conversations into the recyclerview
        FirebaseRecyclerOptions options = new FirebaseRecyclerOptions.Builder<Conversations>().setQuery(conversationQuery, Conversations.class).build();

        //set the adapter with options passed in
        adapter = new FirebaseRecyclerAdapter<Conversations, ConversationsActivity.ConversationsViewHolder>(options) {

            @NonNull
            @Override
            public ConversationsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

                //create a new conversation with viewholder set to the custom user_search_layout
                final View myView = LayoutInflater.from(parent.getContext()).inflate(R.layout.user_search_layout, parent, false);
                return new ConversationsActivity.ConversationsViewHolder(myView);
            }

            @Override
            protected void onBindViewHolder(@NonNull final ConversationsViewHolder holder, int position, @NonNull final Conversations conversations) {

                //get the user that the current user was speaking to
                final String conversation_user = getRef(position).getKey();

                //get the last message sent from the messaging activity in the message database
                Query lastMessageQuery = MessageDatabase.child(conversation_user).limitToLast(1);

                //load that message into the holder
                lastMessageQuery.addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                        String data = dataSnapshot.child("message").getValue().toString();
                        holder.setMessage(data, conversations.isSeen());

                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                    }
                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                    }
                    @Override
                    public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                    }
                });

                //load the user data of the users that the current user is speaking to
                UsersDatabase.child(conversation_user).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        final String username = dataSnapshot.child("username").getValue().toString();
                        String thumb_photo = dataSnapshot.child("thumb_photo").getValue().toString();

                        holder.setUsername(username);

                        try {
                            holder.setThumb_photo(thumb_photo, getApplicationContext());
                        } catch (Exception e) {

                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }
        };

        //set the adapter now that everything is finished setting up
        conversationList.setAdapter(adapter);
    }

    //have the adapter start listening on start up
    @Override
    protected void onStart() {
        super.onStart();

        adapter.startListening();

    }

    //have is stop listening on stop to save memory
    @Override
    public void onStop() {
        super.onStop();

        adapter.stopListening();


    }

    //create the conversations holder, this holds the data for each conversation in the recycler view
    public class ConversationsViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        View myView;
        String userID;

        public ConversationsViewHolder(final View itemView) {
            super(itemView);
            myView = itemView;
            itemView.setOnClickListener(this);
        }

        //bold the last message text if it has not been seen yet.
        public void setMessage(String message, boolean isSeen) {

            TextView last_message = (TextView) myView.findViewById(R.id.txt_userlist_bio);
            last_message.setText(message);

            if (!isSeen) {
                last_message.setTypeface(last_message.getTypeface(), Typeface.BOLD);
            } else {
                last_message.setTypeface(last_message.getTypeface(), Typeface.NORMAL);
            }

        }

        //username passed in when viewholder is bound, text is updated here
        public void setUsername(String username) {
            TextView usernameView = (TextView) myView.findViewById(R.id.txt_userlist_name);
            usernameView.setText(username);
        }

        //thumbnail passed in when viewholder is bound, image is updated here
        public void setThumb_photo(String thumb_photo, Context ctx) {

            CircleImageView mThumbphoto = (CircleImageView) myView.findViewById(R.id.userlist_thumbimage);
            Picasso.with(ctx).load(thumb_photo).placeholder(R.drawable.ic_account2).into(mThumbphoto);

        }

        //handle when the item is clicked in the recyclerview
        //get the id of the person/item clicked and pass into the intent
        //start the messaging activity
        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();

            userID = adapter.getRef(position).getKey();

            Intent intent = new Intent(myView.getContext(), Messaging_Activity.class);
            intent.putExtra("userID", userID);

            startActivity(intent);

        }
    }
}

