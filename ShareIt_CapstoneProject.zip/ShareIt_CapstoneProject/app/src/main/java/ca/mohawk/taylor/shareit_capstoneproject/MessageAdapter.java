package ca.mohawk.taylor.shareit_capstoneproject;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;

/*
 *
 * Share it, Photo sharing and Messaging Application
 *
 * Christopher Taylor, 000377293
 *
 * Mohawk College
 * Software Capstone - COMP-10202-01
 *
 * I, Christopher Taylor, 000377293 certify that this material is my original work.
 * No other person's work has been used without due acknowledgement.
 *
 * */

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.MessageViewHolder> {

    //create a list that will hold the messages between users
    private List<Messages> messagesList;
    private FirebaseAuth firebaseAuth;
    private DatabaseReference UserDatabase;

    public MessageAdapter(List<Messages> messagesList) {
        this.messagesList = messagesList;
    }

    @NonNull
    @Override
    public MessageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        //create a new message with viewholder set to the custom messaging layout
        View myView = LayoutInflater.from(parent.getContext()).inflate(R.layout.message_layout, parent, false);
        return new MessageViewHolder(myView);

    }

    @Override
    public void onBindViewHolder(@NonNull final MessageViewHolder holder, int position) {

        //get current instance of app for firebase
        firebaseAuth = FirebaseAuth.getInstance();

        final Messages messages = messagesList.get(holder.getAdapterPosition());

        //get the user that a message is from, from the database
        String from_user = messages.getFrom();

        String current_user = firebaseAuth.getCurrentUser().getUid();

        try{
            //get the id of the user that a message was from in the users table, in the database
            UserDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child(from_user);
        } catch (Exception e) {

        }

            //load in messaging data
            //get the username, date and thumbnail of the user who sent a message
            UserDatabase.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    String image = dataSnapshot.child("thumb_photo").getValue().toString();
                    String username = dataSnapshot.child("username").getValue().toString();
                    String sourceString = "<b>" + username + "</b>" + " : " + getDate(messages.getTime());

                    holder.timeText.setText(Html.fromHtml(sourceString));

                    //using picasso library to load in the thumbnail from the database
                    try {
                        Picasso.with(holder.messageThumbPhoto.getContext()).load(image)
                                .placeholder(R.drawable.ic_account2).into(holder.messageThumbPhoto);
                    } catch (Exception e) {
                    }

                    holder.messageText.setText(messages.getMessage());

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

    }

    //pass the long time passed in and return the datetime
    private String getDate(long time) {
        Calendar cal = Calendar.getInstance(Locale.ENGLISH);
        cal.setTimeInMillis(time);
        String date = DateFormat.format("MMMM dd hh:mm aa", cal).toString();
        return date;
    }

    //get the size of the messaging list, so the adapter knows how many messages to display
    @Override
    public int getItemCount() {
        return messagesList.size();
    }

    //message viewholder to get the textviews and update them with information
    public class MessageViewHolder extends RecyclerView.ViewHolder {

        public TextView messageText;
        public CircleImageView messageThumbPhoto;
        public TextView timeText;

        public MessageViewHolder(View itemView) {
            super(itemView);

            messageText = (TextView) itemView.findViewById(R.id.message_message_text);
            messageThumbPhoto = (CircleImageView) itemView.findViewById(R.id.message_thumb_photo);
            timeText = (TextView) itemView.findViewById(R.id.message_text_time);

        }
    }
}
