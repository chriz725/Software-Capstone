package ca.mohawk.taylor.shareit_capstoneproject;


import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;


/*
 *
 * Share it, Photo sharing and Messaging Application
 *
 * Christopher Taylor, 000377293
 *
 * Mohawk College
 * Software Capstone - COMP-10202-01
 *
 * I, Christopher Taylor, 000377293 certify that this material is my original work.
 * No other person's work has been used without due acknowledgement.
 *
 * */

/**
 * A simple {@link Fragment} subclass.
 */
public class DialogFragmentNewUser extends DialogFragment {



    public DialogFragmentNewUser() {
    // Required empty public constructor
    }

    Dialog mysavedDialog = null;
    View myView = null;

    //handle creating the dialog
    //this dialog appears when the user creates an account
    //and is displayed for them
    @Override
    public Dialog onCreateDialog(Bundle savedstate) {

        AlertDialog.Builder myBuilder = new AlertDialog.Builder(getActivity(), R.style.AlertDialogCustom);

        LayoutInflater inflater = getActivity().getLayoutInflater();
        myView = inflater.inflate(R.layout.dialog_fragment_welcome, null, false);

        final AccountCreation_Activity creation_activity = (AccountCreation_Activity) getActivity();
        String alert1 = "Thank you for joining the ShareIt team";
        String alert2 = "An app where you can share photos or short videos instantly between friends.";
        String alert3 = "Hit OK to get started!";

        myBuilder.setView(myView);
        myBuilder.setTitle("Welcome!");
        myBuilder.setMessage(alert1 + "\n\n" + alert2 + "\n\n" + alert3);

        //when user is done reading the message and presses ok, they are taken to their account.
        myBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                Intent intent = new Intent(mysavedDialog.getContext(), Account_Activity.class);
                startActivity(intent);
                mysavedDialog.dismiss();

            }


        });

        myBuilder.setView(myView);
        mysavedDialog = myBuilder.create();
        return mysavedDialog;
    }

}
