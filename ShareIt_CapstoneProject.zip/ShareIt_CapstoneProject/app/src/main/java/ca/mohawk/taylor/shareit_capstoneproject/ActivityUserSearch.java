package ca.mohawk.taylor.shareit_capstoneproject;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

/*
 *
 * Share it, Photo sharing and Messaging Application
 *
 * Christopher Taylor, 000377293
 *
 * Mohawk College
 * Software Capstone - COMP-10202-01
 *
 * I, Christopher Taylor, 000377293 certify that this material is my original work.
 * No other person's work has been used without due acknowledgement.
 *
 * */

public class ActivityUserSearch extends AppCompatActivity {

    private RecyclerView userList;
    private EditText userSearch;

    private DatabaseReference UsersDatabase;
    private LinearLayoutManager linearLayoutManager;

    //create an adapter that holds type user and has the users view holder
    private FirebaseRecyclerAdapter<User, ActivityUserSearch.UsersViewHolder> adapter;

    String userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_search);

        linearLayoutManager = new LinearLayoutManager(this);

        //setting up the recyclerview
        userList = (RecyclerView) findViewById(R.id.user_list);
        userList.setHasFixedSize(true);
        userList.setLayoutManager(linearLayoutManager);



        UsersDatabase = FirebaseDatabase.getInstance().getReference().child("Users");

        userSearch = (EditText) findViewById(R.id.editText_search_users);

        //creating a firebase options.
        //this will take a query from the database reference that gets users
        //for the purpose of passing users into the recyclerview
        FirebaseRecyclerOptions options = new FirebaseRecyclerOptions.Builder<User>().setQuery(UsersDatabase, User.class).build();

        //set the adapter with options passed in
        adapter = new FirebaseRecyclerAdapter<User, ActivityUserSearch.UsersViewHolder>(options) {
            @Override
            protected void onBindViewHolder(ActivityUserSearch.UsersViewHolder holder, int position, final User user) {

                //load the users data to the holder
                //get the data from the database
                try {
                    holder.setUsername(user.getUsername(), user.getFirst_name(), user.getLast_name());
                    holder.setBio(user.getBio());
                    holder.setThumb_photo(user.getThumb_photo(), getApplicationContext());

                } catch (Exception e) {
                    //Log.e("Exception", e.toString());
                }
            }

            @NonNull
            @Override
            public ActivityUserSearch.UsersViewHolder onCreateViewHolder(final ViewGroup parent, int viewType) {

                //create a new user with viewholder set to the custom user search layout
                final View myView = LayoutInflater.from(parent.getContext()).inflate(R.layout.user_search_layout, parent, false);
                return new ActivityUserSearch.UsersViewHolder(myView);
            }
        };

        //set the adapter now that everything is finished setting up
        userList.setAdapter(adapter);


    }


    //have the adapter start listening on start up
    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    //have is stop listening on stop to save memory
    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }

    //create the userview holder, this holds the data for each user in the recycler view
    public class UsersViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        View myView;
        String userID;

        public UsersViewHolder(final View itemView) {
            super(itemView);
            myView = itemView;
            itemView.setOnClickListener(this);

        }

        //username passed in when viewholder is bound, text is updated here
        public void setUsername(String username, String firstname, String lastname) {

            TextView mUsername = (TextView) myView.findViewById(R.id.txt_userlist_name);
            mUsername.setText("@" + username + " - " + firstname + " "+ lastname);
        }

        //biography passed in when viewholder is bound, text is updated here
        public void setBio(String bio) {

            TextView mBio = (TextView) myView.findViewById(R.id.txt_userlist_bio);
            mBio.setText(bio);
        }

        //user thumbnails passed in when viewholder is bound, text is updated here
        public void setThumb_photo(String thumb_photo, Context ctx) {

            CircleImageView mThumbphoto = (CircleImageView) myView.findViewById(R.id.userlist_thumbimage);
            Picasso.with(ctx).load(thumb_photo).placeholder(R.drawable.ic_account2).into(mThumbphoto);

    }

        @Override
        public void onClick(View v) {

            //when an item in the viewholder is clicked, get that item position and pass the user's ID into an intent and start
            //the profile activity, allowing the user to view that persons profile
            int position = getAdapterPosition();

            userID = adapter.getRef(position).getKey();

                    Intent intent = new Intent(myView.getContext(), ProfilesActivity.class);
                    intent.putExtra("userID", userID);
                    startActivity(intent);

        }
    }

    //TODO add search functionality to only see users that are based on the search data provided.
//    public Filter getFilter() {
//        return new Filter() {
//            @Override
//            protected FilterResults performFiltering(CharSequence charSequence) {
//                String charString = charSequence.toString();
//                if(charString.isEmpty()) {
//                    user_ListFiltered = user_List;
//                } else {
//                    List<User> filteredList = new ArrayList<>();
//                    for (User row : user_List) {
//
//                        if (row.getUsername().toLowerCase().contains(charString.toLowerCase()) || row.getPhone().contains(charSequence)) {
//                            filteredList.add(row);
//                        }
//                    }
//
//                    user_ListFiltered = filteredList;
//
//                }
//                FilterResults filterResults = new FilterResults();
//                filterResults.values = user_ListFiltered;
//                return filterResults;
//            }
//
//            @Override
//            protected void publishResults(CharSequence constraint, FilterResults filterResults) {
//                user_ListFiltered = (ArrayList<User>) filterResults.values;
//                adapter.notifyDataSetChanged();
//            }
//        };
//    }




}
