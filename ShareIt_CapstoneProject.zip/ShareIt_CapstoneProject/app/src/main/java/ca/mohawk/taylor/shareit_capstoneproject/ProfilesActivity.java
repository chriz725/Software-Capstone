package ca.mohawk.taylor.shareit_capstoneproject;

import android.app.ProgressDialog;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;

/*
 *
 * Share it, Photo sharing and Messaging Application
 *
 * Christopher Taylor, 000377293
 *
 * Mohawk College
 * Software Capstone - COMP-10202-01
 *
 * I, Christopher Taylor, 000377293 certify that this material is my original work.
 * No other person's work has been used without due acknowledgement.
 *
 * */

//TODO insert more user profile information, have that information displayed when the user is a friend. but hidden otherwise

public class ProfilesActivity extends AppCompatActivity {

    private ImageView profileImage;
    private TextView profileName, profileBio, profileFriendCount;
    private Button sendfriendrequestbtn, declinefriendrequestbtn;

    private TextView extraInfo;
    private TextView friendCount;
    private int size;
    private String userID;

    ProgressDialog dialog;

    //initialize current user and databases
    private FirebaseUser current_user;
    private DatabaseReference UsersDatabase;
    private DatabaseReference FriendRequestDatase;
    private DatabaseReference FriendDatabase;
    private DatabaseReference FriendCountDatabase;

    private int current_state;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profiles);

        profileName = (TextView) findViewById(R.id.profile_username);
        profileBio = (TextView) findViewById(R.id.profile_bio);
        profileFriendCount = (TextView) findViewById(R.id.profile_total_friends);

        //get intent data that was passed in, which will be the target user from last activity, profile
        userID = getIntent().getStringExtra("userID");

        //get reference to all the children of the current user
        //get reference to all the friend requests table
        //get reference to all the friends in the database
        UsersDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child(userID);
        FriendRequestDatase = FirebaseDatabase.getInstance().getReference().child("Friend_Reqs");
        FriendDatabase = FirebaseDatabase.getInstance().getReference().child("Friends");

        current_user = FirebaseAuth.getInstance().getCurrentUser();

        profileImage = (ImageView) findViewById(R.id.profile_user_img);
        profileName = (TextView) findViewById(R.id.profile_username);
        profileBio = (TextView) findViewById(R.id.profile_bio);
        profileFriendCount = (TextView) findViewById(R.id.profile_total_friends);
        sendfriendrequestbtn = (Button) findViewById(R.id.btn_send_request);
        declinefriendrequestbtn = (Button) findViewById(R.id.btn_decline_request);

        //set the decline friend request button invisible
        //only needed if a friend request was sent to the current user
        declinefriendrequestbtn.setVisibility(View.INVISIBLE);
        declinefriendrequestbtn.setEnabled(false);

        //current state is the relationship between 2 users.
        // 0 - not friends
        // 1 - pending friend request
        // 2 - friend request received
        // 3 - friends

        //create a dialog notifying the user that the profile data is being loaded
        dialog = new ProgressDialog(this);
        dialog.setTitle("Loading user data");
        dialog.setMessage("Please wait while the user's data is loaded");
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();

        extraInfo = (TextView) findViewById(R.id.profile_extrajnfo);
        extraInfo.setVisibility(View.GONE);
        friendCount = (TextView) findViewById(R.id.profile_total_friends);

        //get number of friends of the current user
        //number of friends is equal to the number of children of the user found in the database friends table
        FriendCountDatabase = FirebaseDatabase.getInstance().getReference().child("Friends").child(userID);
        FriendCountDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                size = (int) dataSnapshot.getChildrenCount();
                friendCount.setText("Total Friends: " + size);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        // handle loading the target users information to be loaded onto the the activity page
        UsersDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                final String username = dataSnapshot.child("username").getValue().toString();
                final String bio = dataSnapshot.child("bio").getValue().toString();
                final String image = dataSnapshot.child("user_photo").getValue().toString();

                profileName.setText(username);
                profileBio.setText(bio);
                profileFriendCount.setText("Number of Friends: 0");

                //Using Picasso library to load in the users profile image
                try {
                    Picasso.with(ProfilesActivity.this).load(image).placeholder(R.drawable.ic_account2).into(profileImage);
                } catch (Exception e){

                }

                // a listener that handles the friend request action in the activity.
                // allows user to cancel the sent friend request if hes the one who sent it
                // allows the user to accept the sent friend request if hes the one who received it
                FriendRequestDatase.child(current_user.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        if(dataSnapshot.hasChild(userID)) {
                            String request_type = dataSnapshot.child(userID).child("request_type").getValue().toString();

                            if(request_type.equals("received")) {
                                current_state = 2;
                                sendfriendrequestbtn.setText("Accept Friend Request");

                                declinefriendrequestbtn.setVisibility(View.VISIBLE);
                                declinefriendrequestbtn.setEnabled(true);

                            } else if(request_type.equals("sent")){
                                current_state = 1;
                                sendfriendrequestbtn.setText("Cancel Friend Request");

                                declinefriendrequestbtn.setVisibility(View.INVISIBLE);
                                declinefriendrequestbtn.setEnabled(false);

                            }
                        }

                        dialog.dismiss();

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                    }
                });

                //when activity is initally loaded, if the user is a friend we want to set the button to unfriend right away
                //and hide the decline friend request button
                FriendDatabase.child(current_user.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        if(dataSnapshot.hasChild(userID)) {
                            current_state = 3;
                            sendfriendrequestbtn.setText("unfriend user");

                            declinefriendrequestbtn.setVisibility(View.INVISIBLE);
                            declinefriendrequestbtn.setEnabled(false);

                            UsersDatabase.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                                    String birthday = dataSnapshot.child("birthday").getValue().toString();
                                    String email = dataSnapshot.child("email").getValue().toString();
                                    String phonenumber = dataSnapshot.child("phone").getValue().toString();
                                    String firstname = dataSnapshot.child("first_name").getValue().toString();
                                    String lastname = dataSnapshot.child("last_name").getValue().toString();

                                    if(birthday.equals("")) {
                                        birthday = "Not Listed";
                                    }
                                    if(phonenumber.equals("")) {
                                        phonenumber = "Not Listed";
                                    }
                                    if(firstname.equals("")){
                                        firstname = "Not Listed";
                                    }
                                    if(lastname.equals("")){
                                        lastname = "Not Listed";
                                    }

                                    extraInfo.setVisibility(View.VISIBLE);
                                    extraInfo.setText("Personal Information \n\n" + "Full Name: " + firstname + " " + lastname + "\n" + "Email: " + email + "\n" + "Phone Number: " + phonenumber + "\n" + "Birthday: " + birthday);

                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }

    //handle the send friend request button being pressed
    public void send_friend_request(View view) {

        //Relationship states between users:
        // 0 - not friends
        // 1 - pending friend request
        // 2 - friend request received
        // 3 - friends

        //initially set it to false, so it cannot be spammed
        sendfriendrequestbtn.setEnabled(false);

        // Handle friend request from one user to another as long as the current state is set to 0
        if(current_state == 0) {

            FriendRequestDatase.child(current_user.getUid()).child(userID).child("request_type")
                    .setValue("sent").addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {

                    if(task.isSuccessful()) {

                        FriendRequestDatase.child(userID).child(current_user.getUid()).child("request_type")
                                .setValue("received").addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {

                                current_state = 1;
                                Toast.makeText(ProfilesActivity.this, "Friend Request Sent", Toast.LENGTH_SHORT).show();
                                sendfriendrequestbtn.setText("Cancel Friend Request");

                                declinefriendrequestbtn.setVisibility(View.INVISIBLE);
                                declinefriendrequestbtn.setEnabled(false);
                               //Toast.makeText(ProfilesActivity.this, "Friend request sent.", Toast.LENGTH_SHORT).show();
                            }
                        });

                    } else {
                        Toast.makeText(ProfilesActivity.this, "Failed to send request.", Toast.LENGTH_SHORT).show();
                    }
                    sendfriendrequestbtn.setEnabled(true);

                }
            });

        }

        //Cancel a pending friend request from one user to another
        if(current_state == 1) {

            FriendRequestDatase.child(current_user.getUid()).child(userID).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {

                    if(task.isSuccessful()) {

                        FriendRequestDatase.child(userID).child(current_user.getUid()).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {

                                if(task.isSuccessful()) {

                                    current_state = 0;
                                    sendfriendrequestbtn.setText("Send Friend Request");

                                    declinefriendrequestbtn.setVisibility(View.INVISIBLE);
                                    declinefriendrequestbtn.setEnabled(false);

                                } else {
                                    Toast.makeText(ProfilesActivity.this, "Failed to cancel friend request", Toast.LENGTH_SHORT).show();
                                }

                            }
                        });

                    } else {
                        Toast.makeText(ProfilesActivity.this, "Failed to cancel friend request", Toast.LENGTH_SHORT).show();
                    }
                    sendfriendrequestbtn.setEnabled(true);
                }

            });

        }

        // Handle a received friend request for acceptance
        if(current_state == 2) {

            final String currentDate = DateFormat.getDateTimeInstance().format(new Date());

            FriendDatabase.child(current_user.getUid()).child(userID).child("Date").setValue(currentDate).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {

                    if(task.isSuccessful()) {

                        FriendDatabase.child(userID).child(current_user.getUid()).child("Date").setValue(currentDate).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {

                                if(task.isSuccessful()) {

                                    FriendRequestDatase.child(current_user.getUid()).child(userID).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {

                                            if(task.isSuccessful()) {

                                                FriendRequestDatase.child(userID).child(current_user.getUid()).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {

                                                        if(task.isSuccessful()) {

                                                            current_state = 3;
                                                            sendfriendrequestbtn.setText("Unfriend user");
                                                            Toast.makeText(ProfilesActivity.this, "User Added", Toast.LENGTH_SHORT).show();

                                                            declinefriendrequestbtn.setVisibility(View.INVISIBLE);
                                                            declinefriendrequestbtn.setEnabled(false);

                                                        } else {
                                                            Toast.makeText(ProfilesActivity.this, "Failed to cancel friend request", Toast.LENGTH_SHORT).show();
                                                        }
                                                    }
                                                });

                                            } else {
                                                Toast.makeText(ProfilesActivity.this, "Failed to cancel friend request", Toast.LENGTH_SHORT).show();
                                            }
                                            sendfriendrequestbtn.setEnabled(true);
                                        }

                                    });

                                } else {
                                    Toast.makeText(ProfilesActivity.this, "Failed to add user as friend", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

                    } else {
                        Toast.makeText(ProfilesActivity.this, "Failed to add user as friend", Toast.LENGTH_SHORT).show();
                    }


                }
            });



        }

        // Handle removing someone friend their friend's list
        if(current_state == 3) {

            FriendDatabase.child(current_user.getUid()).child(userID).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {

                    if(task.isSuccessful()) {

                        FriendDatabase.child(userID).child(current_user.getUid()).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {

                                if(task.isSuccessful()) {

                                    current_state = 0;
                                    sendfriendrequestbtn.setText("Send Friend Request");

                                } else {
                                    Toast.makeText(ProfilesActivity.this, "Failed to unfriend user", Toast.LENGTH_SHORT).show();
                                }

                            }
                        });

                    } else {
                        Toast.makeText(ProfilesActivity.this, "Failed to unfriend user", Toast.LENGTH_SHORT).show();
                    }
                    sendfriendrequestbtn.setEnabled(true);
                }

            });

        }

    }

    public void decline_friend_request(View view) {

        //Cancel a pending friend request from one user to another for declination
        if(current_state == 2) {

            FriendRequestDatase.child(current_user.getUid()).child(userID).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {

                    if(task.isSuccessful()) {

                        FriendRequestDatase.child(userID).child(current_user.getUid()).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {

                                if(task.isSuccessful()) {

                                    current_state = 0;
                                    sendfriendrequestbtn.setText("Send Friend Request");

                                    declinefriendrequestbtn.setVisibility(View.INVISIBLE);
                                    declinefriendrequestbtn.setEnabled(false);

                                } else {
                                    Toast.makeText(ProfilesActivity.this, "Failed to decline friend request", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

                    } else {
                        Toast.makeText(ProfilesActivity.this, "Failed to decline friend request", Toast.LENGTH_SHORT).show();
                    }

                    sendfriendrequestbtn.setEnabled(true);

                }

            });
        }
    }
}
