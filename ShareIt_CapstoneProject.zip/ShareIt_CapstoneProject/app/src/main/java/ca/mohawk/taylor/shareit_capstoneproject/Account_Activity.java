package ca.mohawk.taylor.shareit_capstoneproject;

import android.Manifest;
import android.app.ProgressDialog;
import android.app.VoiceInteractor;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import de.hdodenhof.circleimageview.CircleImageView;
import id.zelory.compressor.Compressor;

/*
*
* Share it, Photo sharing and Messaging Application
*
* Christopher Taylor, 000377293
*
* Mohawk College
* Software Capstone - COMP-10202-01
*
* I, Christopher Taylor, 000377293 certify that this material is my original work.
* No other person's work has been used without due acknowledgement.
*
* */

public class Account_Activity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    //create a reference to the database to query various information
    private DatabaseReference UserDatabase;
    private DatabaseReference FriendDatabase;
    private DatabaseReference WallDatabase;


    private FirebaseUser firebaseUser;

    private CircleImageView profilePicture;
    private TextView username;

    private TextView friendCount;
    private TextView postCount;
    private int size;

    private String caption = "";

    private String dataExtra;

    WallPost wallPost;

    String currentUserID;

    //values that are passed through an intent and when value is received in the listener, do the actions that is requested.
    private static final int GALLERY_PICK = 100;
    private static final int CAMERA_REQUEST_CODE_IMAGE = 200;
    private static final int CAMERA_REQUEST_CODE_VIDEO = 300;
    private static final int REQUEST_CAMERA_PERMISSION = 400;

    //Create a storage reference for Firebase;
    private StorageReference imageStorage;
    private Button takePhotoButton;
    private Button takeVideoButton;

    byte[] thumb_byte;

    private Uri fileUri;
    private Uri imageUri;

    private Boolean isGalleryPhoto = false;

    private DrawerLayout myDrawer = null;
    private ProgressDialog myDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_);

        //get instance of the current firebase user on the phone
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();

        //if there is no user, send them to the login page
        if (firebaseUser == null) {

            Intent intent = new Intent(this, ActivityLogin.class);
            startActivity(intent);

            //if there is a user, start activity normally
        } else {

            //ask user for permission to use the camera, external storage and internet if permissions are missing.
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this, new String[]{
                        Manifest.permission.CAMERA,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.INTERNET
                }, REQUEST_CAMERA_PERMISSION);
                return;
            }

            //Create a dialog
            //use to let the user know that they're information is loading, this usual does take longer
            //if it is the first time running the application
            myDialog = new ProgressDialog(this);
            myDialog.setTitle("Loading");
            myDialog.setMessage("Please wait, your profile is loading...");
            myDialog.setCanceledOnTouchOutside(false);
            myDialog.show();

            myDrawer = (DrawerLayout) findViewById(R.id.drawer_layout);

            //handle creation of navigation view, used to create the nav drawer
            NavigationView myNavigationView = (NavigationView) findViewById(R.id.nav_view);
            myNavigationView.setNavigationItemSelectedListener(this);

            ActionBar actionbar = getSupportActionBar();
            actionbar.setDisplayHomeAsUpEnabled(true);

            ActionBarDrawerToggle myToggler = new ActionBarDrawerToggle(this, myDrawer, R.string.open, R.string.close);
            myDrawer.addDrawerListener(myToggler);

            myToggler.syncState();

            WallDatabase = FirebaseDatabase.getInstance().getReference();

            //set the current user ID to the UID retreived from the database
            String current_uid = firebaseUser.getUid();

            friendCount = (TextView) findViewById(R.id.textFriends);
            postCount = (TextView) findViewById(R.id.textScore);

            //get number of friends of the current user
            //number of friends is equal to the number of children of the user found in the database friends table
            FriendDatabase = FirebaseDatabase.getInstance().getReference().child("Friends").child(current_uid);
            FriendDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    size = (int) dataSnapshot.getChildrenCount();
                    friendCount.setText("" + size);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

            //get the number of posts that the user has uploaded
            WallDatabase = FirebaseDatabase.getInstance().getReference().child("Posts").child(current_uid);
            WallDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    size = (int) dataSnapshot.getChildrenCount();
                    postCount.setText("" + size);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

            //UserDatabase - a database reference that will access the users table and get children of the current user
            UserDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child(current_uid);

            username = (TextView) findViewById(R.id.textUsername);
            imageStorage = FirebaseStorage.getInstance().getReference();
            profilePicture = (CircleImageView) findViewById(R.id.profile_picture_Img);

            UserDatabase.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    //get the the current user's data from the database to populate the account activity with their information.
                    String name = dataSnapshot.child("username").getValue().toString();
                    String image = dataSnapshot.child("user_photo").getValue().toString();
                    String thumb_image = dataSnapshot.child("thumb_photo").getValue().toString();

                    username.setText(name);

                    try {
                        //insert an image using the Picasso libary, with data taken from Firebase, if there is no image, it will default to the placeholder.
                        Picasso.with(Account_Activity.this).load(image).placeholder(R.drawable.ic_account).error(R.drawable.ic_account).into(profilePicture);
                    } catch (Exception e) {

                    }

                    myDialog.dismiss();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

            //create an instance of the take photo button and start the image capture activity for user to take photos
            //intent will pass in a bitmap value of the image and the camera request code
            takePhotoButton = (Button) findViewById(R.id.btnTakePhoto);
            takePhotoButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    isGalleryPhoto = false;
                    String[] options = {"Select from gallery", "Take new photo"};

                    //open an alert dialog with options for the user
                    //user can either open the target user's profile
                    //open the messaging activity to send a message
                    //view the users posts/wall
                    AlertDialog.Builder builder = new AlertDialog.Builder(Account_Activity.this);
                    builder.setTitle("Select Option");
                    builder.setItems(options, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            //handle user selecting to grab an image from the phone or take one themselves
                            //the target user's data is passed through the intent to be loaded in the next activity
                            if(which == 0) {
                                //Navigate to choose a photo from the phones gallery
                                Intent gallery_intent = new Intent();
                                gallery_intent.setType("image/*");
                                gallery_intent.setAction(Intent.ACTION_GET_CONTENT);
                                startActivityForResult(Intent.createChooser(gallery_intent, "Select Image"), CAMERA_REQUEST_CODE_IMAGE);
                                isGalleryPhoto = true;

                            } else if(which == 1){
                                //Navigate to take a new photo with the phone's camera
                                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                                if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                                    startActivityForResult(takePictureIntent, CAMERA_REQUEST_CODE_IMAGE);
                                    isGalleryPhoto = false;
                                }

                            }
                        }
                    });

                    try{
                        builder.show();
                    }catch (Exception exception) {
                        Toast.makeText(Account_Activity.this, "Error: " + exception, Toast.LENGTH_SHORT).show();
                    }
                }
            });

            takeVideoButton = (Button) findViewById(R.id.btnTakeVideo);
            takeVideoButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
                    if (takeVideoIntent.resolveActivity(getPackageManager()) != null) {
                        startActivityForResult(takeVideoIntent, CAMERA_REQUEST_CODE_VIDEO);
                    }
                }
            });
        }
    }


    public void addFriend(View view) {

        //open the user search activity
        //an activity that lists all users who have an account
        //for the purpose of finding friends.
        Intent intent = new Intent(this, ActivityUserSearch.class);
        startActivity(intent);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        //get the current userID
        currentUserID = firebaseUser.getUid();

        //the request code from when the user takes a photo
        if (requestCode == CAMERA_REQUEST_CODE_IMAGE) {

            //if result is OK when picture is taken, continue
            if (resultCode == RESULT_OK) {

                //Alert Dialog when when the photo or video button is clicked to the user can add a caption
                final AlertDialog.Builder builder = new AlertDialog.Builder(Account_Activity.this);
                final LayoutInflater inflater = this.getLayoutInflater();
                View dialogView = inflater.inflate(R.layout.custom_alert_dialog, null);
                builder.setView(dialogView);

                final EditText input = (EditText) dialogView.findViewById(R.id.alert_caption);
                final Button saveButton = (Button) dialogView.findViewById(R.id.alert_savebtn);
                final AlertDialog alertDialog = builder.create();
                alertDialog.show();

                //make sure to only save the image post if the user saves it and finishes writing a caption (can be empty)
                saveButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        //check if the photo is from the gallery or not
                        //when the photo is not from the gallery get the image data as bitmap
                        if(!isGalleryPhoto) {
                            //get the data passed from the intent
                            Bundle extras = data.getExtras();
                            Bitmap imageBitmap = (Bitmap) extras.get("data");

                            //convert the Bitmap into a uri
                            fileUri = getImageUri(getApplicationContext(), imageBitmap);

                            //create a file path in the storage of Firebase to hold images
                            StorageReference filepath = imageStorage.child("shared_photos").child(currentUserID).child(fileUri.getLastPathSegment());

                            filepath.putFile(fileUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                                    if (task.isSuccessful()) {
                                        //Log.e("UPLOAD", "successfully uploaded image");
                                    } else {
                                        Toast.makeText(Account_Activity.this, "Failed to upload image", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });

                            caption = input.getText().toString();

                            postToWall();
                            alertDialog.dismiss();

                        //When the image is from the gallery get the data passed through from that intent
                        //and upload the file the same way the change profile intent works
                        } else {

                            //get the data passed from the intent
                            imageUri = data.getData();

                            //create a file path in the storage of Firebase to hold images
                            StorageReference filepath = imageStorage.child("shared_photos").child(currentUserID).child(imageUri.getLastPathSegment());

                            filepath.putFile(imageUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {

                                    if(task.isSuccessful()) {
                                        //Log.e("UPLOAD", "successfully uploaded image");
                                    } else {
                                        Toast.makeText(Account_Activity.this, "Failed to upload photo from gallery", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });

                            caption = input.getText().toString();

                            postToWall();
                            alertDialog.dismiss();
                        }
                    }
                });

            } else if (resultCode == RESULT_CANCELED) {
                Toast.makeText(this, "Cancelled", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed to save image", Toast.LENGTH_SHORT).show();
            }
        }

        //if the request code is to take a video
        //TODO video functionality is there and adds to database properly, however is not yet able to be posted to the user's wall for viewing
        if (requestCode == CAMERA_REQUEST_CODE_VIDEO) {
            if (resultCode == RESULT_OK) {

                //Alert Dialog when when the photo or video button is clicked to the user can add a caption
                final AlertDialog.Builder builder = new AlertDialog.Builder(Account_Activity.this);
                final LayoutInflater inflater = this.getLayoutInflater();
                View dialogView = inflater.inflate(R.layout.custom_alert_dialog, null);
                builder.setView(dialogView);

                final EditText input = (EditText) dialogView.findViewById(R.id.alert_caption);
                final Button saveButton = (Button) dialogView.findViewById(R.id.alert_savebtn);
                final AlertDialog alertDialog = builder.create();
                alertDialog.show();

                //make sure to only save the video post if the user saves it and finishes writing a caption (can be empty)
                saveButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        fileUri = data.getData();

                        //create a file path in the storage of Firebase to hold video
                        StorageReference filepath = imageStorage.child("shared_videos").child(currentUserID).child(fileUri.getLastPathSegment());

                        filepath.putFile(fileUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                                if (task.isSuccessful()) {
                                    //Toast.makeText(Account_Activity.this, "Finished uploading image", Toast.LENGTH_SHORT).show();
                                    //Log.e("UPLOAD", "successfully uploaded video");

                                    caption = input.getText().toString();
                                    postToWall();
                                    alertDialog.dismiss();

                                } else {
                                    Toast.makeText(Account_Activity.this, "Failed to upload image", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });


                    }
                });
            }
        }

        //if the request code is for changing profile picture
        if (requestCode == GALLERY_PICK && resultCode == RESULT_OK) {

            //get the data passed from the intent
            Uri imageUri = data.getData();

            //start the crop activity
            CropImage.activity(imageUri)
                    .setAspectRatio(1, 1)
                    .start(this);

        }

        //if the crop activity is the request
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {

            CropImage.ActivityResult result = CropImage.getActivityResult(data);

            if (resultCode == RESULT_OK) {

                Uri resultUri = result.getUri();

                File thumb_file = new File(resultUri.getPath());

                currentUserID = firebaseUser.getUid();

                //compress the image down, the image is a thumb_nail so it can be smaller in dimensions and file size
                try {
                    Bitmap thumb_bitmap = new Compressor(this)
                            .setMaxWidth(200)
                            .setMaxHeight(200)
                            .setQuality(75)
                            .compressToBitmap(thumb_file);

                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    thumb_bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                    thumb_byte = baos.toByteArray();

                } catch (IOException e) {
                    e.printStackTrace();
                }

                //create a file path that stores the user images
                //these do not have to be unique because when the user changes their profile picture
                //the file will be replaced thus saving a lot of space in storage
                StorageReference filepath = imageStorage.child("profile_images").child(currentUserID + ".jpg");
                final StorageReference thumb_filepath = imageStorage.child("profile_images").child("thumbnails").child(currentUserID + ".jpg");

                filepath.putFile(resultUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {

                        currentUserID = firebaseUser.getUid();

                        if (task.isSuccessful()) {

                            //get the filepath of the current user's profile picture from storage
                            Toast.makeText(Account_Activity.this, "Image Changed", Toast.LENGTH_SHORT).show();
                            imageStorage.child("profile_images").child(currentUserID + ".jpg").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {

                                    final String download_url = uri.toString();

                                    //upload the thumbnail image to storage in Firebase
                                    UploadTask uploadTask = thumb_filepath.putBytes(thumb_byte);

                                    uploadTask.addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                                        @Override
                                        public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> thumb_task) {

                                            imageStorage.child("profile_images").child("thumbnails").child(currentUserID + ".jpg").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                @Override
                                                public void onSuccess(Uri uri) {

                                                    final String thumb_downloadurl = uri.toString();

                                                    //after the uploading is successful we update the users photo and thumbnail photo data in the database
                                                    Map update_hashmap = new HashMap<>();
                                                    update_hashmap.put("user_photo", download_url);
                                                    update_hashmap.put("thumb_photo", thumb_downloadurl);

                                                    UserDatabase.updateChildren(update_hashmap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                        @Override
                                                        public void onComplete(@NonNull Task<Void> task) {

                                                            if (task.isSuccessful()) {
                                                            } else {
                                                                Toast.makeText(Account_Activity.this, "Error uploading thumbnail", Toast.LENGTH_SHORT).show();
                                                            }
                                                        }
                                                    });
                                                }
                                            });
                                        }
                                    });
                                }
                            });

                        } else {
                            Toast.makeText(Account_Activity.this, "Error uploading", Toast.LENGTH_SHORT).show();
                        }
                    }
                });


            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
            }
        }

    }

    private void postToWall() {

//        String image_source = imageStorage.child("shared_photos").child(currentUserID).child(fileUri.getLastPathSegment()).toString();
//        System.out.println(imageStorage.child("shared_photos").child(currentUserID).child(fileUri.getLastPathSegment()).toString());

        if (caption.equals("")) {
            caption = "No Caption Provided";
        }

        if(!isGalleryPhoto) {
            //create instance of WallPost and get the data that was input by the user to be passed through
            wallPost = new WallPost(fileUri.toString(), caption, System.currentTimeMillis());
        } else {
            wallPost = new WallPost(imageUri.toString(), caption, System.currentTimeMillis());
        }

        //create a reference for the database to generate a random key to make each post unique
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Posts").push();
        //creeate a new Post in the database that holds the information passed from wallpost
        //posts are sorted by the UID -> unique key -> post data
        FirebaseDatabase.getInstance().getReference("Posts/" + FirebaseAuth.getInstance().getCurrentUser().getUid())
                .child(reference.getKey())
                .setValue(wallPost).addOnCompleteListener(new OnCompleteListener<Void>() {

            @Override
            public void onComplete(@NonNull Task<Void> task) {

                //if we're successful user is added to the database and notified of success. otherwise user is told error
                if (task.isSuccessful()) {

                    Intent intent = new Intent(getApplicationContext(), ActivityWall.class);
                    intent.putExtra("userID", currentUserID);
                    startActivity(intent);
//                  Toast.makeText(Account_Activity.this, "Registration Successful", Toast.LENGTH_SHORT).show();
                } else {
                    //Log.e("ERROR", task.getException().toString());
                    Toast.makeText(Account_Activity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

    public void viewFriend(View view) {

        //open the friends list activity for user to view his current friends
        Intent intent = new Intent(this, FriendsActivity.class);
        startActivity(intent);

    }

    //handle converting the Bitmap passed in to a uri for file uploading
    private Uri getImageUri(Context context, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(context.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        //notitify the user he must have persmissions on camera to use the application
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "You can't use the app without camera permission", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }

    //handle selecting items in the nav drawer to open new activities
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        // Show visual for selection
        item.setChecked(true);
        currentUserID = firebaseUser.getUid();

        // Close the Drawer
        myDrawer.closeDrawers();

        switch (item.getItemId()) {
            case R.id.nav_messages:
                //Navigate to messaging page
                Intent message_intent = new Intent(getApplicationContext(), ConversationsActivity.class);
                startActivity(message_intent);
                break;
            case R.id.nav_friends:
                //Navigate to friends page
                Intent friend_intent = new Intent(getApplicationContext(), FriendsActivity.class);
                startActivity(friend_intent);
                break;
            case R.id.nav_share:
                //Navigate to post wall page
                Intent share_intent = new Intent(getApplicationContext(), ActivityWall.class);
                share_intent.putExtra("userID", currentUserID);
                startActivity(share_intent);
                break;
            case R.id.nav_settings:
                //Navigate to settings page
                Intent settings_intent = new Intent(getApplicationContext(), Settings_Activity.class);
                startActivity(settings_intent);
                break;
            case R.id.change_profile_pic:
                //Navigate to change profile picture activity
                Intent gallery_intent = new Intent();
                gallery_intent.setType("image/*");
                gallery_intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(gallery_intent, "Select Image"), GALLERY_PICK);
                break;
            case R.id.logout_main:
                //Navigate to login page
                Intent logout_intent = new Intent(getApplicationContext(), ActivityLogin.class);
                startActivity(logout_intent);
                break;
        }

        return false;

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        // Find out the current state of the drawer (open or closed)
        boolean isOpen = myDrawer.isDrawerOpen(GravityCompat.START);
        // Handle item selection
        switch (item.getItemId()) {
            case android.R.id.home:
                // Home button - open or close the drawer
                if (isOpen == true) {
                    myDrawer.closeDrawer(GravityCompat.START);
                } else {
                    myDrawer.openDrawer(GravityCompat.START);
                }
                return true;
        }

        return super.onOptionsItemSelected(item);

    }
}


