package ca.mohawk.taylor.shareit_capstoneproject;

import android.app.DialogFragment;
import android.app.ProgressDialog;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

/*
 *
 * Share it, Photo sharing and Messaging Application
 *
 * Christopher Taylor, 000377293
 *
 * Mohawk College
 * Software Capstone - COMP-10202-01
 *
 * I, Christopher Taylor, 000377293 certify that this material is my original work.
 * No other person's work has been used without due acknowledgement.
 *
 * */

public class AccountCreation_Activity extends AppCompatActivity {

    //Handle regular expressions for input fields when creating a new user
    public static final String Email_Regex = "^([0-9a-zA-Z]([-.\\w]*[0-9a-zA-Z])*@(([0-9a-zA-Z])+([-\\w]*[0-9a-zA-Z])*\\.)+[a-zA-Z]{2,9})$";
    public static final String Password_Regex = "(?=^.{6,15}$)(?=.*\\d)(?=.*[a-z])(?=. *[A-Z])(?=.*[!@#$%^&amp;*()_+}{&quot;:;'?/&gt;.&lt;,])(?!.*\\s).*$";
    public static final String Username_Regex = "^^[a-zA-Z0-9.-_ ]{3,15}$";

    private EditText txtUsername;
    private EditText txtEmail;
    private EditText txtPassword;
    private EditText txtPasswordConfirm;
    private EditText txtFirstName;
    private EditText txtLastName;
    private EditText txtPhone;

    //create an instance of FirebaseAuth for authorization on user to create.
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_creation_);

        txtUsername = (EditText) findViewById(R.id.txtEdit_UsernameCreate);
        txtEmail = (EditText) findViewById(R.id.txtEdit_EmailCreate);
        txtPassword = (EditText) findViewById(R.id.txtEdit_PasswordCreate);
        txtPasswordConfirm = (EditText) findViewById(R.id.txtEdit_ConfirmPasswordCreate);
        txtFirstName = (EditText) findViewById(R.id.txtEdit_First_Name);
        txtLastName = (EditText) findViewById(R.id.txtEdit_last_Name);
        txtPhone = (EditText) findViewById(R.id.txtEdit_Phone);

        //get current instance of application
        firebaseAuth = FirebaseAuth.getInstance();

    }

    //Handle the actual creation of the account when button is pressed
    public void CreateAccount(View view) {

        //output all the textfield values to strings
        final String username = txtUsername.getText().toString();
        final String email = txtEmail.getText().toString();
        final String firstname = txtFirstName.getText().toString();
        final String lastname = txtLastName.getText().toString();
        final String phonenumber = txtPhone.getText().toString();
        final String password = txtPassword.getText().toString();
        final String passwordConfirm = txtPasswordConfirm.getText().toString();

        final String bio = "Just signed up!";
        final String birthday = "";
        final String user_photo = "";
        final String thumb_photo = "";

        //ensure that the username, email and password meet the required regex.
        //also make sure passwords match and no other fields are empty.
        if (username.matches(Username_Regex)) {

            if (email.matches(Email_Regex)) {

                if (password.matches(Password_Regex)) {

                    if (password.equals(passwordConfirm)) {

                        if (!TextUtils.isEmpty(firstname) || !TextUtils.isEmpty(lastname) || !TextUtils.isEmpty(phonenumber)) {

                            //Notify the user with a dialog the account is being created.
                            final ProgressDialog progressDialog = ProgressDialog.show
                                    (AccountCreation_Activity.this, "Please wait while we register you...", "Processing...", true);

                            //create a user in the database with email and password
                            firebaseAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {


                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {

                                    progressDialog.dismiss();

                                    //when task is sucessful continue
                                    if (task.isSuccessful()) {

                                        Log.e("Registration", "Registration Successful");

                                        //sending extra data into the database table for Users.
                                        User user = new User(
                                                username,
                                                firstname,
                                                lastname,
                                                email,
                                                phonenumber,
                                                birthday,
                                                bio,
                                                user_photo,
                                                thumb_photo
                                        );

                                        //add extra data to user table
                                        FirebaseDatabase.getInstance().getReference("Users")
                                                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                                .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {

                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {

                                                //if we're successful, user is added to the database and notified of success. otherwise user is told there was an error
                                                if (task.isSuccessful()) {
                                                    Toast.makeText(AccountCreation_Activity.this, "Registration Successful", Toast.LENGTH_SHORT).show();
                                                } else {
                                                    Log.e("ERROR", task.getException().toString());
                                                    Toast.makeText(AccountCreation_Activity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                                }

                                            }
                                        });

                                        //open dialog fragemnt upon success welcoming user to the application
                                        DialogFragment welcomeMessage = new DialogFragmentNewUser();
                                        welcomeMessage.show(getFragmentManager(), "DialogFragmentNewUser");


                                    } else {
                                        Log.e("ERROR", task.getException().toString());
                                        Toast.makeText(AccountCreation_Activity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                    }

                                }
                            });

                            //general error handling, user is notified if there was an issue with the data in the fields
                        } else {
                            Toast.makeText(AccountCreation_Activity.this, "First Name, Last Name and Phone Number are required.", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(AccountCreation_Activity.this, "Passwords must match", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(AccountCreation_Activity.this, "Password must be between 6 and 15 characters, contain a number and a capital", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(AccountCreation_Activity.this, "Valid email required", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(AccountCreation_Activity.this, "Username must be between 3 and 15 characters", Toast.LENGTH_LONG).show();
        }

    }
}
