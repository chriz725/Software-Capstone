package ca.mohawk.taylor.shareit_capstoneproject;

import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
 *
 * Share it, Photo sharing and Messaging Application
 *
 * Christopher Taylor, 000377293
 *
 * Mohawk College
 * Software Capstone - COMP-10202-01
 *
 * I, Christopher Taylor, 000377293 certify that this material is my original work.
 * No other person's work has been used without due acknowledgement.
 *
 * */

public class Messaging_Activity extends AppCompatActivity {

    private String chatUser;

    private FirebaseUser firebaseUser;
    private DatabaseReference UserDatabase;

    private FirebaseAuth firebaseAuth;

    private String current_user;

    private EditText messageText;

    private RecyclerView message_list;
    private final List<Messages> messagesList = new ArrayList<>();

    private LinearLayoutManager linearLayoutManager;
    private MessageAdapter adapter;

    private static final int Items_Loaded = 10;
    private int Items_Position = 0;
    private String last_key = "";
    private String previous_key = "";
    private int current_page = 1;

    private SwipeRefreshLayout refreshLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_messaging_);

        //get the current user logged into the device
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();

        //if no user is logged in, open the login activity
        if (firebaseUser == null) {

            Intent intent = new Intent(this, ActivityLogin.class);
            startActivity(intent);

        //if user is logged in, continue normally
        } else {

            messageText = (EditText) findViewById(R.id.editText_msgText);

            message_list = (RecyclerView) findViewById(R.id.message_list);
            linearLayoutManager = new LinearLayoutManager(this);

            //create a new adapter that takes a list of messages
            adapter = new MessageAdapter(messagesList);

            refreshLayout = (SwipeRefreshLayout) findViewById(R.id.message_refresh_layout);

            message_list.setHasFixedSize(true);
            message_list.setLayoutManager(linearLayoutManager);

            //set the adapter to the recyclerview
            message_list.setAdapter(adapter);

            //get the current instance of the app, for firebase
            firebaseAuth = FirebaseAuth.getInstance();
            //get the ID of the current user
            current_user = firebaseAuth.getCurrentUser().getUid();

            //get the ID of the user the current user is speaking to, which was passed in from the conversations activity
            chatUser = getIntent().getStringExtra("userID");
            UserDatabase = FirebaseDatabase.getInstance().getReference();

            //get the messages from the database
            getMessages();

            //display the user's name of the user, that the current user is speaking to
            UserDatabase.child("Users").child(chatUser).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    String username = dataSnapshot.child("username").getValue().toString();
                    getSupportActionBar().setTitle(username);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

            //create a chat table in the database with the current user and the target user.
            //which stores time of message and boolean if message was seen or not
            UserDatabase.child("Chat").child(current_user).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    if(!dataSnapshot.hasChild(chatUser)) {

                        Map chatMap = new HashMap();
                        chatMap.put("seen", false);
                        chatMap.put("timestamp", ServerValue.TIMESTAMP);

                        Map chatUserMap = new HashMap();
                        chatUserMap.put("Chat/" + current_user + "/" + chatUser, chatMap);
                        chatUserMap.put("Chat/" + chatUser + "/" + current_user, chatMap);

                        UserDatabase.updateChildren(chatUserMap, new DatabaseReference.CompletionListener() {
                            @Override
                            public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {

                            if(databaseError != null) {
                                Log.d("Log Error", databaseError.getMessage().toString());
                            }
                            }
                        });
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }
            });
        }

        //create a listener for the refresher layout
        //when the user swipes down the page is refreshed.
        refreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

            //when the page is refreshed more messages are loaded into the app
            current_page++;
            Items_Position = 0;
            getMoreMessages();

            }
        });
    }

    //handle the send button being pressed.
    //call send message function which sends the message stored in the edittext field
    public void sendMessage(View view) {
        sendMessage();
    }

    private void sendMessage() {

        //get the text in the edittext field
        String message = messageText.getText().toString();

        //if its not empty continue
        if(!TextUtils.isEmpty(message)) {

            //create 2 references for the database
            //each reference is for the messages table and each user has eachother as a child
            String current_user_reference = "Messages/" + current_user + "/" + chatUser;
            String chat_user_reference = "Messages/" + chatUser + "/" + current_user;

            //creating another reference to push data into the database
            DatabaseReference user_message_push = UserDatabase.child("Messages").child(current_user).child(chatUser).push();

            String pushID = user_message_push.getKey();

            //map the data for the database
            //with Key : Value, relationship
            Map messageMap = new HashMap();
            messageMap.put("message", message);
            messageMap.put("send", false);
            messageMap.put("type", "text");
            messageMap.put("time", ServerValue.TIMESTAMP);
            messageMap.put("from", current_user);

            //create a new Map that with put the current user, the target user and the map data into the database all at once
            Map messageUserMap = new HashMap();
            messageUserMap.put(current_user_reference + "/" + pushID, messageMap);
            messageUserMap.put(chat_user_reference + "/" + pushID, messageMap);

            //update the database with the data in the Map
            UserDatabase.updateChildren(messageUserMap, new DatabaseReference.CompletionListener() {
                @Override
                public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {

                if(databaseError != null) {
                    Log.d("Log Error", databaseError.getMessage().toString());
                }

                }
            });

            //set the textbox to blank when message is sent
            messageText.setText("");
        }
    }

    //handle loading messages into the recyclerview from the database
    private void getMessages() {

        //get all the messages in the database between current user and target user
        DatabaseReference messageReference = UserDatabase.child("Messages").child(current_user).child(chatUser);

        //load all the messages in reverse order so they display at the bottom
        //only load 10 messages as indicated by items_loaded.
        Query message_query = messageReference.limitToLast(current_page * Items_Loaded);
        message_query.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                Messages messages = dataSnapshot.getValue(Messages.class);

                Items_Position++;

                if(Items_Position == 1) {
                    String message_key = dataSnapshot.getKey();
                    last_key = message_key;
                    previous_key = message_key;

                }

                messagesList.add(messages);
                adapter.notifyDataSetChanged();
                message_list.scrollToPosition(messagesList.size()-1);
                refreshLayout.setRefreshing(false);

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
            }
            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
            }
            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

    }

    //handle loading more messages into the recyclerview
    //important for pagination
    //only 10 messages are loaded initially, but each time the view is refreshed more messages are loaded in.
    private void getMoreMessages() {

        //get all the messages in the database between current user and target user
        DatabaseReference messageReference = UserDatabase.child("Messages").child(current_user).child(chatUser);

        //load all the messages in reverse order so they display at the bottom
        //load from the last message displayed, load 10 more exluding that last message
        Query message_query = messageReference.orderByKey().endAt(last_key).limitToLast(Items_Loaded);
        message_query.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                Messages messages = dataSnapshot.getValue(Messages.class);
                String message_key = dataSnapshot.getKey();

                if(!previous_key.equals(message_key)) {
                    messagesList.add(Items_Position++, messages);
                } else {
                    previous_key = last_key;
                }

                if(Items_Position == 1) {
                    last_key = message_key;
                }

                adapter.notifyDataSetChanged();
                refreshLayout.setRefreshing(false);
                linearLayoutManager.scrollToPositionWithOffset(10, 0);

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
            }
            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
            }
            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });


    }

}
